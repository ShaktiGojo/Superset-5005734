package com.yourcompany.repository;

public interface EmployeeNameProjection {
    String getName();
}
